# MINISO Staff Performance & Incentive Management System

A responsive staff-management dashboard built from the original Java AWT project. It includes staff-directory CRUD, performance reviews, incentive tracking, and the supplied eight-day project work log.

## Features

- Sign-in protected dashboard and staff directory.
- Add, search, update, remove, and export staff profiles as CSV.
- Performance reviews with 0–100 scores, period, reviewer, and notes.
- Incentive records with target/achieved sales, rupee amounts, and pending/approved/paid statuses.
- Day 1–8 project work log; the date fields begin blank and save in the current browser.
- Persistent staff, review, and incentive records using MySQL/TiDB through Drizzle ORM.

## Tech stack

React 19, TypeScript, Vite, Tailwind CSS, Express, tRPC, Drizzle ORM, and MySQL/TiDB.

## Requirements

- Node.js 22 or a compatible recent Node.js release.
- pnpm.
- A MySQL/TiDB database and the authentication configuration used by the web-app template.

## Local development

```bash
pnpm install
pnpm dev
```

Open the local URL printed by Vite/server. The app's routes require authentication. When running outside the Manus-hosted environment, configure the server's database and OAuth environment variables before use; see `server/_core/env.ts` for the required names and `drizzle.config.ts` for the database setup.

## Database

The schema lives in `drizzle/schema.ts`. A migration is included under `drizzle/`.

```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

Only run migrations against a database you control. Protect database credentials and OAuth secrets in your hosting provider's environment settings; never commit `.env` files or secret values.

## Validation

```bash
pnpm check
pnpm test
pnpm build
```

## Push to your Git remote

Create an empty repository with your preferred Git host, then run these commands in the project directory (replace the URL with your own repository URL):

```bash
git init
git add .
git commit -m "Build MINISO staff management website"
git branch -M main
git remote add origin https://github.com/YOUR-NAME/YOUR-REPOSITORY.git
git push -u origin main
```

The `.gitignore` excludes dependencies, build output, local environment files, logs, and generated project metadata.

## Important

Staff records, review details, phone numbers, and email addresses may be personal information. Use real employee data only in an authorized, access-controlled deployment. The work-log dates are saved locally in the browser and are not part of the database backup.

## License

Add a license that matches how you intend to use and distribute this project before making the repository public.
