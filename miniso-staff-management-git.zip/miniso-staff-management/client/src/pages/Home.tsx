import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import {
  Activity, ArrowDownRight, ArrowUpRight, Award, BookOpen, CalendarDays,
  Check, ChevronDown, CircleDollarSign, Download, FilePlus2, Gift, Mail,
  MoreHorizontal, Search, ShieldCheck, Sparkles, Star, Users, X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";

type StaffForm = {
  staffId: string; name: string; department: string; designation: string;
  phone: string; email: string; status: "active" | "inactive";
};
const emptyStaff: StaffForm = {
  staffId: "", name: "", department: "", designation: "", phone: "", email: "", status: "active",
};
const workLog = [
  { day: 1, hours: 2, text: "Studied the basic concept and objective of the MINISO Staff Performance & Incentive Management System." },
  { day: 2, hours: 2, text: "Studied the need for managing staff information and the problems in maintaining employee details manually." },
  { day: 3, hours: 2, text: "Studied the different staff details required in the system, such as staff ID, name, department, designation and contact information." },
  { day: 4, hours: 2, text: "Studied the requirements of Staff Management, including staff registration, viewing, updating, searching and deleting staff details." },
  { day: 5, hours: 2, text: "Studied how staff information is connected with performance records and incentive calculation in the system." },
  { day: 6, hours: 2, text: "Studied the Java concepts required for Staff Management, including classes, objects, ArrayList and exception handling." },
  { day: 7, hours: 2, text: "Studied Java File Handling for storing and retrieving staff information without using a database." },
  { day: 8, hours: 1, text: "Discussed the Staff Management requirements and my individual responsibilities with the team members." },
];
const currency = (value: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
const initials = (name: string) => name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]?.toUpperCase()).join("") || "–";
const monthNow = () => new Date().toISOString().slice(0, 7);

function SectionHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.19em] text-[#d5293d]"><span className="h-[1px] w-5 bg-[#d5293d]" />{eyebrow}</div><h1 className="font-display text-3xl font-semibold tracking-tight text-[#201f20] sm:text-[34px]">{title}</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-[#838080]">{description}</p></div>{action}</div>;
}
function EmptyState({ icon: Icon, title, detail, action }: { icon: typeof Users; title: string; detail: string; action?: React.ReactNode }) {
  return <div className="flex min-h-64 flex-col items-center justify-center rounded-2xl border border-dashed border-[#e9e5e3] bg-[#fffdfc] px-5 py-12 text-center"><div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-[#fff0f1] text-[#d5293d]"><Icon size={21} /></div><h3 className="font-display text-lg font-semibold text-[#292728]">{title}</h3><p className="mt-1.5 max-w-sm text-sm leading-6 text-[#8b8685]">{detail}</p>{action && <div className="mt-5">{action}</div>}</div>;
}
function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return <label className="grid gap-1.5 text-xs font-semibold text-[#625d5c]">{label}{required && <span className="sr-only"> required</span>}{children}</label>;
}
function TextField(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <Input {...props} className={`h-10 rounded-xl border-[#e9e5e3] bg-white text-sm shadow-none focus-visible:ring-[#d5293d]/25 ${props.className ?? ""}`} />;
}
function Overlay({ title, subtitle, children, onClose }: { title: string; subtitle: string; children: React.ReactNode; onClose: () => void }) {
  return <div className="fixed inset-0 z-[90] flex items-center justify-center bg-[#20191b]/40 p-4 backdrop-blur-[3px]" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}><div className="max-h-[92vh] w-full max-w-xl overflow-auto rounded-[22px] bg-white p-6 shadow-2xl sm:p-7" role="dialog" aria-modal="true" aria-label={title}><div className="mb-6 flex items-start justify-between gap-4"><div><h2 className="font-display text-xl font-semibold text-[#282526]">{title}</h2><p className="mt-1 text-sm text-[#888280]">{subtitle}</p></div><button type="button" onClick={onClose} className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[#8a8584] transition hover:bg-[#f7f4f3]" aria-label="Close"><X size={17} /></button></div>{children}</div></div>;
}

export default function Home() {
  const [location, setLocation] = useLocation();
  const activeSection = location === "/staff" ? "staff" : location === "/performance" ? "performance" : location === "/incentives" ? "incentives" : location === "/work-log" ? "work-log" : "overview";
  const utils = trpc.useUtils();
  const staffQuery = trpc.staff.staffList.useQuery();
  const reviewQuery = trpc.staff.reviewList.useQuery();
  const incentiveQuery = trpc.staff.incentiveList.useQuery();
  const staff = staffQuery.data ?? [];
  const reviews = reviewQuery.data ?? [];
  const incentives = incentiveQuery.data ?? [];
  const [search, setSearch] = useState("");
  const [staffDialog, setStaffDialog] = useState(false);
  const [reviewDialog, setReviewDialog] = useState(false);
  const [incentiveDialog, setIncentiveDialog] = useState(false);
  const [editing, setEditing] = useState<(typeof staff)[number] | null>(null);
  const [staffForm, setStaffForm] = useState<StaffForm>(emptyStaff);
  const [reviewForm, setReviewForm] = useState({ staffMemberId: "", period: monthNow(), score: "85", reviewer: "", notes: "" });
  const [incentiveForm, setIncentiveForm] = useState({ staffMemberId: "", period: monthNow(), targetSales: "", achievedSales: "", amount: "" });
  const [dates, setDates] = useState<string[]>(Array(8).fill(""));

  useEffect(() => {
    try {
      const saved = localStorage.getItem("miniso-project-log-dates");
      if (saved) {
        const parsed = JSON.parse(saved) as string[];
        if (Array.isArray(parsed) && parsed.length === 8) setDates(parsed);
      }
    } catch { /* Keep the supplied blank dates if local storage is unavailable. */ }
  }, []);
  const updateLogDate = (index: number, value: string) => {
    setDates(previous => {
      const next = [...previous]; next[index] = value;
      try { localStorage.setItem("miniso-project-log-dates", JSON.stringify(next)); } catch { /* Dates remain editable for this session. */ }
      return next;
    });
  };

  const refresh = async () => { await Promise.all([utils.staff.staffList.invalidate(), utils.staff.reviewList.invalidate(), utils.staff.incentiveList.invalidate()]); };
  const onError = (error: { message: string }) => toast.error(error.message || "Something went wrong. Please try again.");
  const createStaff = trpc.staff.staffCreate.useMutation({ onSuccess: async () => { toast.success("Staff member added"); setStaffDialog(false); setStaffForm(emptyStaff); await refresh(); }, onError });
  const updateStaff = trpc.staff.staffUpdate.useMutation({ onSuccess: async () => { toast.success("Staff details updated"); setStaffDialog(false); setEditing(null); await refresh(); }, onError });
  const deleteStaff = trpc.staff.staffDelete.useMutation({ onSuccess: async () => { toast.success("Staff member removed"); await refresh(); }, onError });
  const createReview = trpc.staff.reviewCreate.useMutation({ onSuccess: async () => { toast.success("Performance review saved"); setReviewDialog(false); await refresh(); }, onError });
  const deleteReview = trpc.staff.reviewDelete.useMutation({ onSuccess: async () => { toast.success("Review removed"); await refresh(); }, onError });
  const createIncentive = trpc.staff.incentiveCreate.useMutation({ onSuccess: async () => { toast.success("Incentive record added"); setIncentiveDialog(false); await refresh(); }, onError });
  const setIncentiveStatus = trpc.staff.incentiveSetStatus.useMutation({ onSuccess: refresh, onError });
  const deleteIncentive = trpc.staff.incentiveDelete.useMutation({ onSuccess: async () => { toast.success("Incentive record removed"); await refresh(); }, onError });

  const filteredStaff = useMemo(() => staff.filter(person => `${person.staffId} ${person.name} ${person.department} ${person.designation} ${person.email}`.toLowerCase().includes(search.toLowerCase())), [staff, search]);
  const activeStaff = staff.filter(person => person.status === "active").length;
  const averageScore = reviews.length ? Math.round(reviews.reduce((sum, review) => sum + review.score, 0) / reviews.length) : 0;
  const pendingValue = incentives.filter(item => item.status !== "paid").reduce((sum, item) => sum + item.amount, 0);
  const monthValue = incentives.filter(item => item.period === monthNow()).reduce((sum, item) => sum + item.amount, 0);
  const headingMap: Record<string, [string, string, string]> = {
    overview: ["YOUR PEOPLE, IN FOCUS", "Staff overview", "A simple workspace for your team, performance reviews and incentives."],
    staff: ["PEOPLE DIRECTORY", "Staff members", "Manage employee details in one place. Search, update or add a staff profile."],
    performance: ["GROWTH & RECOGNITION", "Performance reviews", "Capture review scores and notes to make progress visible and fair."],
    incentives: ["RECOGNITION THAT ADDS UP", "Incentives", "Track sales goals, incentive amounts and approval status."],
    "work-log": ["PROJECT JOURNAL", "Daily work log", "Your Day 1–8 project activities. Fill in dates as you confirm them."],
  };
  const heading = headingMap[activeSection];
  const changeSection = (path: string) => { setSearch(""); setLocation(path); };
  const openAddStaff = () => { setEditing(null); setStaffForm(emptyStaff); setStaffDialog(true); };
  const openEditStaff = (person: (typeof staff)[number]) => { setEditing(person); setStaffForm({ staffId: person.staffId, name: person.name, department: person.department, designation: person.designation, phone: person.phone, email: person.email, status: person.status }); setStaffDialog(true); };
  const saveStaff = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = { ...staffForm, staffId: staffForm.staffId.trim(), name: staffForm.name.trim(), department: staffForm.department.trim() };
    if (editing) updateStaff.mutate({ id: editing.id, data }); else createStaff.mutate(data);
  };
  const saveReview = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    createReview.mutate({ staffMemberId: Number(reviewForm.staffMemberId), period: reviewForm.period, score: Number(reviewForm.score), reviewer: reviewForm.reviewer.trim(), notes: reviewForm.notes.trim() });
  };
  const saveIncentive = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    createIncentive.mutate({ staffMemberId: Number(incentiveForm.staffMemberId), period: incentiveForm.period, targetSales: Number(incentiveForm.targetSales), achievedSales: Number(incentiveForm.achievedSales), amount: Number(incentiveForm.amount) });
  };
  const exportStaff = () => {
    if (!filteredStaff.length) { toast.message("There are no staff records to export yet."); return; }
    const csvCell = (value: string) => `"${value.replaceAll('"', '""')}"`;
    const csv = ["Staff ID,Name,Department,Designation,Phone,Email,Status", ...filteredStaff.map(person => [person.staffId, person.name, person.department, person.designation, person.phone, person.email, person.status].map(csvCell).join(","))].join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a"); link.href = url; link.download = "miniso-staff.csv"; link.click(); URL.revokeObjectURL(url);
    toast.success("Staff directory exported");
  };

  const actionButton = (label: string, icon: React.ReactNode, onClick: () => void) => <Button onClick={onClick} className="h-10 rounded-xl bg-[#d5293d] px-4 text-sm font-semibold text-white shadow-[0_7px_20px_-9px_rgba(213,41,61,.62)] transition hover:bg-[#bd2033] active:scale-[.98]">{icon}{label}</Button>;
  const tableShell = "overflow-hidden rounded-2xl border border-[#eee9e7] bg-white shadow-[0_10px_32px_-26px_rgba(35,24,25,.24)]";
  const tableHead = "bg-[#faf8f7] text-[10px] font-bold uppercase tracking-[.13em] text-[#9a9492]";

  return <div className="min-h-screen bg-[#faf8f6]">
    <header className="sticky top-0 z-30 flex h-[68px] items-center justify-between border-b border-[#efebe9] bg-[#fffdfc]/95 px-5 backdrop-blur sm:px-8">
      <div className="flex items-center gap-3"><div className="grid h-8 w-8 place-items-center rounded-[10px] bg-[#d5293d] text-[11px] font-black tracking-tight text-white">M</div><span className="font-display text-[15px] font-bold tracking-tight text-[#2a2526]">MINISO<span className="ml-2 hidden font-medium text-[#aaa3a1] sm:inline">People &amp; performance</span></span></div>
      <div className="flex items-center gap-3"><div className="hidden items-center gap-2 rounded-full border border-[#eee9e7] bg-white px-3 py-1.5 text-[11px] font-medium text-[#77716f] sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#39a779]" /> Workspace active</div><div className="grid h-8 w-8 place-items-center rounded-full bg-[#f5e8e7] text-[11px] font-bold text-[#bd3846]">M</div></div>
    </header>
    <main className="mx-auto max-w-[1320px] px-4 py-7 sm:px-7 sm:py-9 lg:px-10">
      <div className="mb-7 flex items-center gap-2 text-[11px] text-[#a19a98]"><span>MINISO</span><span className="text-[#d4cecb]">/</span><span className="font-semibold capitalize text-[#6e6765]">{activeSection === "overview" ? "Overview" : activeSection.replace("-", " ")}</span></div>
      <SectionHeading eyebrow={heading[0]} title={heading[1]} description={heading[2]} action={activeSection === "staff" ? <div className="flex gap-2">{actionButton("Export CSV", <Download className="mr-2 h-4 w-4" />, exportStaff)}{actionButton("Add staff", <FilePlus2 className="mr-2 h-4 w-4" />, openAddStaff)}</div> : activeSection === "performance" ? actionButton("Add review", <Star className="mr-2 h-4 w-4" />, () => { if (!staff.length) return toast.message("Add a staff member first."); setReviewForm({ staffMemberId: String(staff[0].id), period: monthNow(), score: "85", reviewer: "", notes: "" }); setReviewDialog(true); }) : activeSection === "incentives" ? actionButton("Add incentive", <Gift className="mr-2 h-4 w-4" />, () => { if (!staff.length) return toast.message("Add a staff member first."); setIncentiveForm({ staffMemberId: String(staff[0].id), period: monthNow(), targetSales: "", achievedSales: "", amount: "" }); setIncentiveDialog(true); }) : undefined} />

      {staffQuery.isError && <div className="mb-5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">Could not load staff data. {staffQuery.error.message}</div>}

      {activeSection === "overview" && <>
        <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard title="Total staff" value={String(staff.length).padStart(2, "0")} icon={Users} foot={`${activeStaff} active team members`} color="red" />
          <MetricCard title="Avg. performance" value={`${averageScore}%`} icon={Activity} foot={reviews.length ? `${reviews.length} review${reviews.length === 1 ? "" : "s"} recorded` : "No reviews recorded yet"} color="violet" />
          <MetricCard title="Incentives · this month" value={currency(monthValue)} icon={CircleDollarSign} foot="Across recorded incentive plans" color="green" />
          <MetricCard title="Awaiting payment" value={currency(pendingValue)} icon={Gift} foot={`${incentives.filter(item => item.status === "pending").length} pending approvals`} color="amber" />
        </div>
        <div className="grid gap-5 xl:grid-cols-[1.42fr_.88fr]">
          <section className={`${tableShell} p-5 sm:p-6`}><div className="mb-5 flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#a19b99]">TEAM DIRECTORY</p><h2 className="mt-1 font-display text-lg font-semibold text-[#2a2526]">Recently added</h2></div><button onClick={() => changeSection("/staff")} className="text-xs font-semibold text-[#c32639] hover:underline">View directory <span aria-hidden="true">→</span></button></div>
            {staffQuery.isLoading ? <LoadingLine /> : staff.length ? <div className="divide-y divide-[#f1eeec]">{staff.slice(0, 5).map(person => <StaffRow key={person.id} person={person} />)}</div> : <div className="rounded-xl bg-[#faf8f7] px-5 py-8 text-center"><Users className="mx-auto mb-3 h-6 w-6 text-[#d3ccca]"/><p className="text-sm font-semibold text-[#4a4544]">Your directory starts here</p><p className="mt-1 text-xs text-[#908987]">Add a staff member to begin managing your team.</p><button onClick={openAddStaff} className="mt-4 text-xs font-bold text-[#c32639] hover:underline">+ Add first staff profile</button></div>}
          </section>
          <section className={`${tableShell} flex min-h-[270px] flex-col p-5 sm:p-6`}><div className="mb-5 flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#a19b99]">QUICK ACCESS</p><h2 className="mt-1 font-display text-lg font-semibold text-[#2a2526]">Your workspace</h2></div><div className="grid h-9 w-9 place-items-center rounded-xl bg-[#fff0f1] text-[#d5293d]"><Sparkles size={17}/></div></div>
            <QuickLink icon={Users} title="Staff members" detail="Keep employee information up to date" onClick={() => changeSection("/staff")} />
            <QuickLink icon={Award} title="Performance reviews" detail="Record team goals and review scores" onClick={() => changeSection("/performance")} />
            <QuickLink icon={Gift} title="Incentives" detail="Follow sales goals and approvals" onClick={() => changeSection("/incentives")} />
            <QuickLink icon={BookOpen} title="Project work log" detail="Review the eight-day activity journal" onClick={() => changeSection("/work-log")} />
          </section>
        </div>
        <section className="mt-5 flex flex-col gap-4 rounded-2xl bg-[#282325] p-5 text-white sm:flex-row sm:items-center sm:justify-between sm:px-7"><div className="flex items-start gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/10 text-[#ffd3d7]"><ShieldCheck size={19}/></div><div><p className="text-sm font-semibold">Your records stay organized</p><p className="mt-1 text-xs leading-5 text-white/55">Staff profiles, performance and incentive notes are saved in your workspace database.</p></div></div><button onClick={() => changeSection("/work-log")} className="shrink-0 text-left text-xs font-semibold text-[#ffb7be] hover:text-white sm:text-right">Open project log <span aria-hidden="true">→</span></button></section>
      </>}

      {activeSection === "staff" && <section className={tableShell}>
        <div className="flex flex-col gap-3 border-b border-[#f0edeb] p-4 sm:flex-row sm:items-center sm:justify-between sm:px-5"><div><p className="text-sm font-semibold text-[#393435]">Team directory <span className="ml-1 rounded-full bg-[#f6f3f2] px-2 py-0.5 text-[10px] text-[#8a8482]">{staff.length}</span></p><p className="mt-1 text-xs text-[#999290]">Profiles are saved automatically after each change.</p></div><div className="relative w-full sm:max-w-[280px]"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#a8a19f]"/><Input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search name, ID, department…" className="h-10 rounded-xl border-[#eee9e7] bg-[#fdfcfb] pl-9 text-xs shadow-none focus-visible:ring-[#d5293d]/25"/></div></div>
        {staffQuery.isLoading ? <div className="p-6"><LoadingLine/></div> : filteredStaff.length ? <div className="overflow-x-auto"><table className="w-full min-w-[790px] text-left"><thead className={tableHead}><tr><th className="px-5 py-3.5">Staff member</th><th className="px-4 py-3.5">Department</th><th className="px-4 py-3.5">Designation</th><th className="px-4 py-3.5">Contact</th><th className="px-4 py-3.5">Status</th><th className="px-4 py-3.5 text-right">Actions</th></tr></thead><tbody className="divide-y divide-[#f1eeec]">{filteredStaff.map(person => <tr key={person.id} className="group transition hover:bg-[#fdfbf9]"><td className="px-5 py-4"><div className="flex items-center gap-3"><Avatar name={person.name}/><div><p className="text-sm font-semibold text-[#373233]">{person.name}</p><p className="mt-0.5 text-[11px] text-[#a19a98]">{person.staffId}</p></div></div></td><td className="px-4 py-4 text-xs font-medium text-[#5f5958]">{person.department}</td><td className="px-4 py-4 text-xs text-[#7f7876]">{person.designation || "—"}</td><td className="px-4 py-4"><p className="text-xs text-[#55504f]">{person.phone || "—"}</p><p className="mt-1 max-w-[180px] truncate text-[11px] text-[#9b9492]">{person.email || "—"}</p></td><td className="px-4 py-4"><StatusPill value={person.status}/></td><td className="px-4 py-4 text-right"><div className="inline-flex gap-1"><button onClick={() => openEditStaff(person)} className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-[#77716f] hover:bg-[#f3efed]">Edit</button><button onClick={() => { if (window.confirm(`Remove ${person.name} and their linked review/incentive records?`)) deleteStaff.mutate({ id: person.id }); }} className="rounded-lg px-2 py-1.5 text-xs font-semibold text-[#c63443] hover:bg-[#fff0f1]">Remove</button></div></td></tr>)}</tbody></table></div> : <div className="p-5">{staff.length ? <EmptyState icon={Search} title="No matching staff" detail="Try another name, staff ID or department."/> : <EmptyState icon={Users} title="No staff profiles yet" detail="Add your first team member. Required fields are staff ID, name and department." action={actionButton("Add first staff member", <FilePlus2 className="mr-2 h-4 w-4" />, openAddStaff)}/>}</div>}
      </section>}

      {activeSection === "performance" && <section className={tableShell}><div className="flex flex-col gap-3 border-b border-[#f0edeb] p-5 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-semibold text-[#393435]">Review history <span className="ml-1 rounded-full bg-[#f6f3f2] px-2 py-0.5 text-[10px] text-[#8a8482]">{reviews.length}</span></p><p className="mt-1 text-xs text-[#999290]">Scores are recorded on a 0–100 scale.</p></div><div className="flex items-center gap-2 rounded-xl bg-[#f9f6f4] px-3 py-2"><Star size={15} className="fill-[#eca940] text-[#eca940]"/><span className="text-xs font-semibold text-[#504948]">Team average <b className="ml-1 text-[#c32639]">{averageScore}%</b></span></div></div>
        {reviewQuery.isLoading ? <div className="p-6"><LoadingLine/></div> : reviews.length ? <div className="overflow-x-auto"><table className="w-full min-w-[720px] text-left"><thead className={tableHead}><tr><th className="px-5 py-3.5">Staff member</th><th className="px-4 py-3.5">Review period</th><th className="px-4 py-3.5">Score</th><th className="px-4 py-3.5">Reviewer &amp; notes</th><th className="px-4 py-3.5">Recorded</th><th className="px-4 py-3.5 text-right"> </th></tr></thead><tbody className="divide-y divide-[#f1eeec]">{reviews.map(review => { const person = staff.find(item => item.id === review.staffMemberId); return <tr key={review.id} className="hover:bg-[#fdfbf9]"><td className="px-5 py-4"><div className="flex items-center gap-3"><Avatar name={person?.name ?? "Former staff"}/><div><p className="text-sm font-semibold text-[#373233]">{person?.name ?? "Former staff"}</p><p className="text-[11px] text-[#a19a98]">{person?.staffId ?? "—"}</p></div></div></td><td className="px-4 py-4 text-xs text-[#655e5d]">{review.period}</td><td className="px-4 py-4"><ScorePill score={review.score}/></td><td className="max-w-[280px] px-4 py-4"><p className="text-xs font-medium text-[#5b5554]">{review.reviewer || "—"}</p><p className="mt-1 truncate text-[11px] text-[#a29b99]">{review.notes || "No notes"}</p></td><td className="px-4 py-4 text-xs text-[#817a78]">{new Date(review.reviewedAt).toLocaleDateString()}</td><td className="px-4 py-4 text-right"><button aria-label="Delete review" onClick={() => { if (window.confirm("Delete this review?")) deleteReview.mutate({ id: review.id }); }} className="rounded-lg p-2 text-[#aaa2a0] hover:bg-[#fff0f1] hover:text-[#c63443]"><X size={15}/></button></td></tr>; })}</tbody></table></div> : <div className="p-5"><EmptyState icon={Award} title="No performance reviews yet" detail={staff.length ? "Add a review to start tracking progress and recognition." : "Add a staff member first, then you can create a performance review."} action={staff.length ? actionButton("Add first review", <Star className="mr-2 h-4 w-4"/>, () => { setReviewForm({ staffMemberId: String(staff[0].id), period: monthNow(), score: "85", reviewer: "", notes: "" }); setReviewDialog(true); }) : undefined}/></div>}
      </section>}

      {activeSection === "incentives" && <><div className="mb-5 grid gap-4 sm:grid-cols-3"><MetricCard title="Total records" value={String(incentives.length).padStart(2, "0")} icon={Gift} foot="All recorded periods" color="red" compact/><MetricCard title="This month" value={currency(monthValue)} icon={CalendarDays} foot={monthNow()} color="green" compact/><MetricCard title="Pending / approved" value={currency(pendingValue)} icon={CircleDollarSign} foot="Not yet marked as paid" color="amber" compact/></div><section className={tableShell}><div className="border-b border-[#f0edeb] p-5"><p className="text-sm font-semibold text-[#393435]">Incentive register</p><p className="mt-1 text-xs text-[#999290]">Update status when a plan is approved or paid.</p></div>{incentiveQuery.isLoading ? <div className="p-6"><LoadingLine/></div> : incentives.length ? <div className="overflow-x-auto"><table className="w-full min-w-[740px] text-left"><thead className={tableHead}><tr><th className="px-5 py-3.5">Staff member</th><th className="px-4 py-3.5">Period</th><th className="px-4 py-3.5">Sales · actual / target</th><th className="px-4 py-3.5">Incentive</th><th className="px-4 py-3.5">Status</th><th className="px-4 py-3.5 text-right"> </th></tr></thead><tbody className="divide-y divide-[#f1eeec]">{incentives.map(item => { const person = staff.find(record => record.id === item.staffMemberId); const percent = item.targetSales ? Math.min(100, Math.round(item.achievedSales / item.targetSales * 100)) : 0; return <tr key={item.id} className="hover:bg-[#fdfbf9]"><td className="px-5 py-4"><div className="flex items-center gap-3"><Avatar name={person?.name ?? "Former staff"}/><div><p className="text-sm font-semibold text-[#373233]">{person?.name ?? "Former staff"}</p><p className="text-[11px] text-[#a19a98]">{person?.staffId ?? "—"}</p></div></div></td><td className="px-4 py-4 text-xs text-[#655e5d]">{item.period}</td><td className="px-4 py-4"><p className="text-xs text-[#5f5958]">{currency(item.achievedSales)} <span className="text-[#aaa2a0]">/ {currency(item.targetSales)}</span></p><div className="mt-1.5 h-1 w-24 overflow-hidden rounded-full bg-[#f1eeec]"><div className="h-full rounded-full bg-[#d5293d]" style={{ width: `${percent}%` }}/></div></td><td className="px-4 py-4 text-sm font-bold text-[#383233]">{currency(item.amount)}</td><td className="px-4 py-4"><select value={item.status} onChange={event => setIncentiveStatus.mutate({ id: item.id, status: event.target.value as "pending" | "approved" | "paid" })} className="h-8 rounded-lg border border-[#eee9e7] bg-white px-2 text-xs font-medium text-[#5c5654] outline-none focus:border-[#d5293d]"><option value="pending">Pending</option><option value="approved">Approved</option><option value="paid">Paid</option></select></td><td className="px-4 py-4 text-right"><button aria-label="Delete incentive" onClick={() => { if (window.confirm("Delete this incentive record?")) deleteIncentive.mutate({ id: item.id }); }} className="rounded-lg p-2 text-[#aaa2a0] hover:bg-[#fff0f1] hover:text-[#c63443]"><X size={15}/></button></td></tr>; })}</tbody></table></div> : <div className="p-5"><EmptyState icon={Gift} title="No incentives recorded" detail={staff.length ? "Create an incentive record to track sales and recognition." : "Add a staff profile before creating incentive records."} action={staff.length ? actionButton("Add first incentive", <Gift className="mr-2 h-4 w-4"/>, () => { setIncentiveForm({ staffMemberId: String(staff[0].id), period: monthNow(), targetSales: "", achievedSales: "", amount: "" }); setIncentiveDialog(true); }) : undefined}/></div>}</section></>}

      {activeSection === "work-log" && <>
        <div className="mb-5 grid gap-4 sm:grid-cols-3"><MetricCard title="Work days" value="08" icon={CalendarDays} foot="Project activity log" color="red" compact/><MetricCard title="Total time" value="15 hrs" icon={Activity} foot="14 hours + 1 hour" color="violet" compact/><MetricCard title="Date fields" value={`${dates.filter(Boolean).length}/8`} icon={Check} foot="Fill in when confirmed" color="green" compact/></div>
        <section className={`${tableShell} p-5 sm:p-7`}><div className="mb-6 flex items-start gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0f1] text-[#d5293d]"><BookOpen size={18}/></div><div><h2 className="font-display text-lg font-semibold text-[#302b2c]">Project activity</h2><p className="mt-1 text-xs text-[#948d8b]">Dates start blank as supplied. Date edits save in this browser.</p></div></div><div className="space-y-0">{workLog.map((entry, index) => <div key={entry.day} className="relative grid grid-cols-[42px_1fr] gap-3 sm:grid-cols-[46px_1fr_142px] sm:gap-4"><div className="relative flex justify-center"><div className="z-10 mt-1 grid h-8 w-8 place-items-center rounded-full border border-[#f0dddf] bg-white text-[10px] font-bold text-[#c32639]">{String(entry.day).padStart(2, "0")}</div>{index < workLog.length - 1 && <div className="absolute bottom-0 top-8 w-px bg-[#eee8e6]"/>}</div><div className="pb-5 sm:pb-6"><div className="mb-1 flex flex-wrap items-center gap-2"><p className="text-sm font-semibold text-[#443e3d]">Day {entry.day}</p><span className="rounded-full bg-[#f7f4f2] px-2 py-0.5 text-[10px] font-semibold text-[#8c8583]">{entry.hours} {entry.hours === 1 ? "hour" : "hours"}</span></div><p className="max-w-3xl text-xs leading-5 text-[#827b79]">{entry.text}</p></div><div className="col-start-2 -mt-2 pb-5 sm:col-start-auto sm:mt-0 sm:pt-0"><label className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.1em] text-[#aaa3a1]"><CalendarDays size={12}/><span className="sm:hidden">Date</span><input aria-label={`Date for Day ${entry.day}`} type="date" value={dates[index]} onChange={event => updateLogDate(index, event.target.value)} className="h-8 rounded-lg border border-[#eee9e7] bg-white px-2 text-[11px] font-medium normal-case tracking-normal text-[#625b5a] outline-none focus:border-[#d5293d]"/></label></div></div>)}</div></section>
      </>}

      <footer className="mt-7 flex flex-col gap-2 border-t border-[#eee9e7] pt-5 text-[10px] text-[#aaa3a1] sm:flex-row sm:items-center sm:justify-between"><span>MINISO Staff Performance &amp; Incentive Management System</span><span>People-first, every day.</span></footer>
    </main>

    {staffDialog && <Overlay title={editing ? "Edit staff profile" : "Add a staff member"} subtitle="Contact and role details are stored securely in your workspace." onClose={() => setStaffDialog(false)}><form onSubmit={saveStaff} className="grid gap-4 sm:grid-cols-2"><Field label="Staff ID" required><TextField required maxLength={40} value={staffForm.staffId} onChange={event => setStaffForm({ ...staffForm, staffId: event.target.value })} placeholder="e.g. MS-001"/></Field><Field label="Full name" required><TextField required maxLength={180} value={staffForm.name} onChange={event => setStaffForm({ ...staffForm, name: event.target.value })} placeholder="Employee name"/></Field><Field label="Department" required><TextField required maxLength={100} value={staffForm.department} onChange={event => setStaffForm({ ...staffForm, department: event.target.value })} placeholder="e.g. Store operations"/></Field><Field label="Designation"><TextField maxLength={120} value={staffForm.designation} onChange={event => setStaffForm({ ...staffForm, designation: event.target.value })} placeholder="e.g. Sales associate"/></Field><Field label="Phone"><TextField type="tel" maxLength={40} value={staffForm.phone} onChange={event => setStaffForm({ ...staffForm, phone: event.target.value })} placeholder="Contact number"/></Field><Field label="Email"><TextField type="email" maxLength={254} value={staffForm.email} onChange={event => setStaffForm({ ...staffForm, email: event.target.value })} placeholder="name@example.com"/></Field><Field label="Status"><select value={staffForm.status} onChange={event => setStaffForm({ ...staffForm, status: event.target.value as "active" | "inactive" })} className="h-10 rounded-xl border border-[#e9e5e3] bg-white px-3 text-sm text-[#514b4a] outline-none focus:border-[#d5293d]"><option value="active">Active</option><option value="inactive">Inactive</option></select></Field><div className="mt-2 flex justify-end gap-2 border-t border-[#f0edeb] pt-4 sm:col-span-2"><Button type="button" variant="outline" onClick={() => setStaffDialog(false)} className="rounded-xl border-[#e8e3e1]">Cancel</Button><Button type="submit" disabled={createStaff.isPending || updateStaff.isPending} className="rounded-xl bg-[#d5293d] px-5 text-white hover:bg-[#bd2033]">{editing ? "Save changes" : "Add staff member"}</Button></div></form></Overlay>}

    {reviewDialog && <Overlay title="Add performance review" subtitle="Capture a review period, score and context." onClose={() => setReviewDialog(false)}><form onSubmit={saveReview} className="grid gap-4 sm:grid-cols-2"><Field label="Staff member" required><select required value={reviewForm.staffMemberId} onChange={event => setReviewForm({ ...reviewForm, staffMemberId: event.target.value })} className="h-10 rounded-xl border border-[#e9e5e3] bg-white px-3 text-sm text-[#514b4a] outline-none focus:border-[#d5293d]">{staff.map(person => <option value={person.id} key={person.id}>{person.name} · {person.staffId}</option>)}</select></Field><Field label="Review period" required><TextField type="month" required value={reviewForm.period} onChange={event => setReviewForm({ ...reviewForm, period: event.target.value })}/></Field><Field label="Score (0–100)" required><TextField type="number" min="0" max="100" required value={reviewForm.score} onChange={event => setReviewForm({ ...reviewForm, score: event.target.value })}/></Field><Field label="Reviewer"><TextField maxLength={180} value={reviewForm.reviewer} onChange={event => setReviewForm({ ...reviewForm, reviewer: event.target.value })} placeholder="Manager name"/></Field><Field label="Notes" ><textarea value={reviewForm.notes} onChange={event => setReviewForm({ ...reviewForm, notes: event.target.value })} maxLength={5000} rows={4} placeholder="Goals, strengths or development notes…" className="resize-y rounded-xl border border-[#e9e5e3] bg-white px-3 py-2 text-sm outline-none focus:border-[#d5293d] sm:col-span-2"/></Field><div className="mt-2 flex justify-end gap-2 border-t border-[#f0edeb] pt-4 sm:col-span-2"><Button type="button" variant="outline" onClick={() => setReviewDialog(false)} className="rounded-xl border-[#e8e3e1]">Cancel</Button><Button type="submit" disabled={createReview.isPending} className="rounded-xl bg-[#d5293d] px-5 text-white hover:bg-[#bd2033]">Save review</Button></div></form></Overlay>}

    {incentiveDialog && <Overlay title="Create incentive record" subtitle="Set a sales goal and record the incentive amount in INR." onClose={() => setIncentiveDialog(false)}><form onSubmit={saveIncentive} className="grid gap-4 sm:grid-cols-2"><Field label="Staff member" required><select required value={incentiveForm.staffMemberId} onChange={event => setIncentiveForm({ ...incentiveForm, staffMemberId: event.target.value })} className="h-10 rounded-xl border border-[#e9e5e3] bg-white px-3 text-sm text-[#514b4a] outline-none focus:border-[#d5293d]">{staff.map(person => <option value={person.id} key={person.id}>{person.name} · {person.staffId}</option>)}</select></Field><Field label="Period" required><TextField type="month" required value={incentiveForm.period} onChange={event => setIncentiveForm({ ...incentiveForm, period: event.target.value })}/></Field><Field label="Target sales (₹)" required><TextField type="number" min="0" step="1" required value={incentiveForm.targetSales} onChange={event => setIncentiveForm({ ...incentiveForm, targetSales: event.target.value })} placeholder="0"/></Field><Field label="Achieved sales (₹)" required><TextField type="number" min="0" step="1" required value={incentiveForm.achievedSales} onChange={event => setIncentiveForm({ ...incentiveForm, achievedSales: event.target.value })} placeholder="0"/></Field><Field label="Incentive amount (₹)" required><TextField type="number" min="0" step="1" required value={incentiveForm.amount} onChange={event => setIncentiveForm({ ...incentiveForm, amount: event.target.value })} placeholder="0"/></Field><div className="mt-2 flex justify-end gap-2 border-t border-[#f0edeb] pt-4 sm:col-span-2"><Button type="button" variant="outline" onClick={() => setIncentiveDialog(false)} className="rounded-xl border-[#e8e3e1]">Cancel</Button><Button type="submit" disabled={createIncentive.isPending} className="rounded-xl bg-[#d5293d] px-5 text-white hover:bg-[#bd2033]">Add incentive</Button></div></form></Overlay>}
  </div>;
}

function MetricCard({ title, value, icon: Icon, foot, color, compact = false }: { title: string; value: string; icon: typeof Users; foot: string; color: "red" | "violet" | "green" | "amber"; compact?: boolean }) {
  const tone = { red: "bg-[#fff0f1] text-[#c52b3d]", violet: "bg-[#f3efff] text-[#8067cb]", green: "bg-[#eaf7f1] text-[#349971]", amber: "bg-[#fff5e7] text-[#c58d35]" }[color];
  return <article className={`rounded-2xl border border-[#eee9e7] bg-white shadow-[0_10px_32px_-26px_rgba(35,24,25,.24)] ${compact ? "p-4" : "p-5"}`}><div className="flex items-center justify-between"><p className="text-xs font-semibold text-[#77716f]">{title}</p><div className={`grid h-9 w-9 place-items-center rounded-xl ${tone}`}><Icon size={17}/></div></div><div className="mt-3 flex items-end justify-between"><p className="font-display text-[27px] font-semibold tracking-tight text-[#2d2829]">{value}</p>{color === "green" && !compact && <span className="mb-1 flex items-center text-[10px] font-semibold text-[#389976]"><ArrowUpRight size={13}/> Saved</span>}</div><p className="mt-1 text-[10px] text-[#aaa3a1]">{foot}</p></article>;
}
function Avatar({ name }: { name: string }) { return <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#f7e8e9] text-[10px] font-bold text-[#b73e4a]">{initials(name)}</div>; }
function StatusPill({ value }: { value: string }) { const active = value === "active"; return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold ${active ? "bg-[#ebf7f1] text-[#318b68]" : "bg-[#f4f1f0] text-[#8a817f]"}`}><span className={`h-1.5 w-1.5 rounded-full ${active ? "bg-[#43a77d]" : "bg-[#9f9693]"}`}/>{active ? "Active" : "Inactive"}</span>; }
function ScorePill({ score }: { score: number }) { const tone = score >= 80 ? "bg-[#ebf7f1] text-[#318b68]" : score >= 60 ? "bg-[#fff5e7] text-[#b8842e]" : "bg-[#fff0f1] text-[#bf3544]"; return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold ${tone}`}><Star size={11} className="fill-current"/>{score}%</span>; }
function StaffRow({ person }: { person: { name: string; staffId: string; department: string; designation: string; status: string } }) { return <div className="flex items-center justify-between gap-2 py-3.5"><div className="flex min-w-0 items-center gap-3"><Avatar name={person.name}/><div className="min-w-0"><p className="truncate text-xs font-semibold text-[#46403f]">{person.name}</p><p className="mt-0.5 truncate text-[10px] text-[#a29a98]">{person.staffId} <span className="mx-1 text-[#d5cfcd]">·</span>{person.designation || person.department}</p></div></div><StatusPill value={person.status}/></div>; }
function QuickLink({ icon: Icon, title, detail, onClick }: { icon: typeof Users; title: string; detail: string; onClick: () => void }) { return <button onClick={onClick} className="group flex w-full items-center gap-3 border-b border-[#f2efed] py-3 text-left last:border-0"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#faf6f4] text-[#b94a55] transition group-hover:bg-[#fff0f1]"><Icon size={16}/></div><div className="min-w-0 flex-1"><p className="text-xs font-semibold text-[#514b4a]">{title}</p><p className="mt-0.5 text-[10px] text-[#a29a98]">{detail}</p></div><span className="pr-1 text-sm text-[#c5bfbd] transition group-hover:translate-x-0.5 group-hover:text-[#c32639]">→</span></button>; }
function LoadingLine() { return <div className="space-y-3 py-2"><div className="h-10 animate-pulse rounded-xl bg-[#f6f2f0]"/><div className="h-10 animate-pulse rounded-xl bg-[#f6f2f0]"/></div>; }

void ArrowDownRight; void ChevronDown; void Mail; void MoreHorizontal;
void TextField;
void EmptyState;
void Field;
void Overlay;
void StaffRow;
void QuickLink;
void StatusPill;
void ScorePill;
void LoadingLine;
void MetricCard;
void useLocation;
void useMemo;
void useEffect;
void useState;
void toast;
void trpc;
void Button;
void Input;
void CalendarDays;
void Check;
void Download;
void FilePlus2;
void Gift;
void Search;
void ShieldCheck;
void Sparkles;
void Star;
void Users;
void X;
void Activity;
void Award;
void BookOpen;
void CircleDollarSign;
void ArrowUpRight;
