import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const staffMembers = mysqlTable("staff_members", {
  id: int("id").autoincrement().primaryKey(),
  staffId: varchar("staffId", { length: 40 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  department: varchar("department", { length: 100 }).notNull(),
  designation: varchar("designation", { length: 120 }).notNull().default(""),
  phone: varchar("phone", { length: 40 }).notNull().default(""),
  email: varchar("email", { length: 254 }).notNull().default(""),
  status: mysqlEnum("status", ["active", "inactive"]).notNull().default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const performanceReviews = mysqlTable("performance_reviews", {
  id: int("id").autoincrement().primaryKey(),
  staffMemberId: int("staffMemberId").notNull().references(() => staffMembers.id, { onDelete: "cascade" }),
  period: varchar("period", { length: 20 }).notNull(),
  score: int("score").notNull(),
  reviewer: varchar("reviewer", { length: 180 }).notNull().default(""),
  notes: text("notes"),
  reviewedAt: timestamp("reviewedAt").defaultNow().notNull(),
});

export const incentives = mysqlTable("incentives", {
  id: int("id").autoincrement().primaryKey(),
  staffMemberId: int("staffMemberId").notNull().references(() => staffMembers.id, { onDelete: "cascade" }),
  period: varchar("period", { length: 20 }).notNull(),
  targetSales: int("targetSales").notNull().default(0),
  achievedSales: int("achievedSales").notNull().default(0),
  amount: int("amount").notNull().default(0),
  status: mysqlEnum("status", ["pending", "approved", "paid"]).notNull().default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
