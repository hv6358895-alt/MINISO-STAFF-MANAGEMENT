CREATE TABLE `incentives` (
	`id` int AUTO_INCREMENT NOT NULL,
	`staffMemberId` int NOT NULL,
	`period` varchar(20) NOT NULL,
	`targetSales` int NOT NULL DEFAULT 0,
	`achievedSales` int NOT NULL DEFAULT 0,
	`amount` int NOT NULL DEFAULT 0,
	`status` enum('pending','approved','paid') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `incentives_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `performance_reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`staffMemberId` int NOT NULL,
	`period` varchar(20) NOT NULL,
	`score` int NOT NULL,
	`reviewer` varchar(180) NOT NULL DEFAULT '',
	`notes` text,
	`reviewedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `performance_reviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `staff_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`staffId` varchar(40) NOT NULL,
	`name` varchar(180) NOT NULL,
	`department` varchar(100) NOT NULL,
	`designation` varchar(120) NOT NULL DEFAULT '',
	`phone` varchar(40) NOT NULL DEFAULT '',
	`email` varchar(254) NOT NULL DEFAULT '',
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `staff_members_id` PRIMARY KEY(`id`),
	CONSTRAINT `staff_members_staffId_unique` UNIQUE(`staffId`)
);
--> statement-breakpoint
ALTER TABLE `incentives` ADD CONSTRAINT `incentives_staffMemberId_staff_members_id_fk` FOREIGN KEY (`staffMemberId`) REFERENCES `staff_members`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `performance_reviews` ADD CONSTRAINT `performance_reviews_staffMemberId_staff_members_id_fk` FOREIGN KEY (`staffMemberId`) REFERENCES `staff_members`(`id`) ON DELETE cascade ON UPDATE no action;