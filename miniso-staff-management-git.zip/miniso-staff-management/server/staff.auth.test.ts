import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createAnonymousContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("staff data authorization", () => {
  it("requires authentication to read the staff directory", async () => {
    const caller = appRouter.createCaller(createAnonymousContext());

    await expect(caller.staff.staffList()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("requires authentication before creating staff records", async () => {
    const caller = appRouter.createCaller(createAnonymousContext());

    await expect(
      caller.staff.staffCreate({
        staffId: "DEMO-001",
        name: "Demo Employee",
        department: "Store operations",
        designation: "Sales associate",
        phone: "",
        email: "",
        status: "active",
      }),
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
