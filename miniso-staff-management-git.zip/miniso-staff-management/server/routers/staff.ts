import { z } from "zod";
import { desc, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { incentives, performanceReviews, staffMembers } from "../../drizzle/schema";
import { getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

const staffInput = z.object({
  staffId: z.string().trim().min(1).max(40),
  name: z.string().trim().min(1).max(180),
  department: z.string().trim().min(1).max(100),
  designation: z.string().trim().max(120).default(""),
  phone: z.string().trim().max(40).default(""),
  email: z.string().trim().max(254).default(""),
  status: z.enum(["active", "inactive"]).default("active"),
});

const reviewInput = z.object({
  staffMemberId: z.number().int().positive(),
  period: z.string().trim().min(1).max(20),
  score: z.number().int().min(0).max(100),
  reviewer: z.string().trim().max(180).default(""),
  notes: z.string().trim().max(5000).default(""),
});

const incentiveInput = z.object({
  staffMemberId: z.number().int().positive(),
  period: z.string().trim().min(1).max(20),
  targetSales: z.number().int().min(0),
  achievedSales: z.number().int().min(0),
  amount: z.number().int().min(0),
});

async function requireDb() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
  return db;
}

export const staffRouter = router({
  staffList: protectedProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(staffMembers).orderBy(desc(staffMembers.createdAt));
  }),
  staffCreate: protectedProcedure.input(staffInput).mutation(async ({ input }) => {
    const db = await requireDb();
    await db.insert(staffMembers).values(input);
    return { success: true };
  }),
  staffUpdate: protectedProcedure.input(z.object({ id: z.number().int().positive(), data: staffInput })).mutation(async ({ input }) => {
    const db = await requireDb();
    await db.update(staffMembers).set(input.data).where(eq(staffMembers.id, input.id));
    return { success: true };
  }),
  staffDelete: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
    const db = await requireDb();
    await db.delete(staffMembers).where(eq(staffMembers.id, input.id));
    return { success: true };
  }),
  reviewList: protectedProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(performanceReviews).orderBy(desc(performanceReviews.reviewedAt));
  }),
  reviewCreate: protectedProcedure.input(reviewInput).mutation(async ({ input }) => {
    const db = await requireDb();
    await db.insert(performanceReviews).values(input);
    return { success: true };
  }),
  reviewDelete: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
    const db = await requireDb();
    await db.delete(performanceReviews).where(eq(performanceReviews.id, input.id));
    return { success: true };
  }),
  incentiveList: protectedProcedure.query(async () => {
    const db = await requireDb();
    return db.select().from(incentives).orderBy(desc(incentives.createdAt));
  }),
  incentiveCreate: protectedProcedure.input(incentiveInput).mutation(async ({ input }) => {
    const db = await requireDb();
    await db.insert(incentives).values(input);
    return { success: true };
  }),
  incentiveSetStatus: protectedProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["pending", "approved", "paid"]) })).mutation(async ({ input }) => {
    const db = await requireDb();
    await db.update(incentives).set({ status: input.status }).where(eq(incentives.id, input.id));
    return { success: true };
  }),
  incentiveDelete: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
    const db = await requireDb();
    await db.delete(incentives).where(eq(incentives.id, input.id));
    return { success: true };
  }),
});

export default staffRouter;
